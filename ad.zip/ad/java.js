function handleLogin(event) {
    event.preventDefault();

    // Get email and password values
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // Basic validation check
    if (email && password) {
        alert("Login successful!");
        // Redirect or further processing can be added here
    } else {
        alert("Please enter a valid email and password.");
    }
}
