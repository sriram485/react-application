// JavaScript to dynamically add products or handle interactivity

document.addEventListener('DOMContentLoaded', () => {
    console.log('Page Loaded');
    // You can add additional dynamic functionalities here.
});
// Toggle Profile Dropdown
const profileButton = document.getElementById('profileButton');
const profileDropdown = document.getElementById('profileDropdown');

profileButton.addEventListener('click', () => {
    profileDropdown.style.display = profileDropdown.style.display === 'block' ? 'none' : 'block';
});

// Close the dropdown if the user clicks outside
window.addEventListener('click', (event) => {
    if (!profileButton.contains(event.target) && !profileDropdown.contains(event.target)) {
        profileDropdown.style.display = 'none';
    }
});
